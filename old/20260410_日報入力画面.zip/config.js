// 日報システムの設定データ
const CONFIG = {
  "names": [
    "田代恭子",
    "佐々木由希江"
  ],
  "categories": [
    "NEWTON対応",
    "運用保守支援",
    "会議"
  ],
  "taskNames": [
    "NEWTON受入テスト",
    "NEWTON本番移行",
    "後追いKEY採番",
    "レビュー管理作業",
    "MDM月次報告会",
    "打合せ/レビュー"
  ]
};
